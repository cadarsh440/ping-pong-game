# Ping-pong-game
This repository contains ping-pong-game web application by using Html | Css | Java Script
I used html to structure the rods and ball to play ping pong game
Used Css to style it and align it properly.
Java-script is used to handle the the keyboard events 

#User Manual
To start the game press Enter.
And to move Rods to left side press A to move to Right side press D
